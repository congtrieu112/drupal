<?php  print render($page['header']); ?>

<section class="cd-faq">
    <?php print drupal_render($page['sidebar_left']); ?>


	<div class="cd-faq-items">
    <?php print drupal_render($page['content']); ?>


	</div> <!-- cd-faq-items -->
	<a href="#0" class="cd-close-panel">Close</a>
</section> <!-- cd-faq -->