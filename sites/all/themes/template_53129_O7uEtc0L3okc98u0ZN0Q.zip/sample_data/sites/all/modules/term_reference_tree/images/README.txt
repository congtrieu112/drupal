The icons contained in this directory are from the FatCow "Farm-Fresh Web Icons" 
collection, available under the Creative Commons Attribution 3.0 license.  They
can be downloaded here:

http://www.fatcow.com/free-icons