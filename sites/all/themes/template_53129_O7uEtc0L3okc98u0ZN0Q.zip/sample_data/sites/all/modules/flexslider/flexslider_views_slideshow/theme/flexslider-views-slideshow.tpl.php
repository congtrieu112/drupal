<?php

/**
 * @file
 * Template for the FlexSlider wrapper
 *
 * @author Mathew Winstone (minorOffense) <mwinstone@coldfrontlabs.ca>
 */

// @todo get views slideshow to use this template. At the moment it seems to
// ignore it.

// @todo see if theme_views_slideshow_main_section can be changed to be overridable
// see line 162 in views_slideshow.theme.inc
?>