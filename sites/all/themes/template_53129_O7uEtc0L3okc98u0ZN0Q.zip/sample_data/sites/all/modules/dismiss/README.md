Dismiss
=======

This module adds jQuery-powered Dismiss buttons to each block of messages that
Drupal outputs. There are three default types: status, warning, and error

The Dismiss button allows you to quickly close messages and errors that get in
the way of what you're doing. For themers, it's an easy way to sidestep other
PHP errors that might be in your codebase. For end-users and site admins, it's
a simple way to make your website a tad more user-friendly.
