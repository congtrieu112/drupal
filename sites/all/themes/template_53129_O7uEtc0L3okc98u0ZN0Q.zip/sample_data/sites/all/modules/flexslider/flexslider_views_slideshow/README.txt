About
===========

Adds a new "Slideshow Type" to Views Slideshow called "Flex Slider".

Usage
======

Enable Views, Views Slideshow and Flex Slider Views Slideshow (note: you do NOT need to enable Flex Slider Views). Create/Edit a View, select a display mode of "Slideshow". In the settings for your display, set the "Slideshow Type" to "Flex Slider", select your option set, set any other options you'd like.

Save your view and you're good to go.