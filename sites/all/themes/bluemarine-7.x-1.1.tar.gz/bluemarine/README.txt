This is the Bluemarine theme that was included as part of Drupal 6, 5, and 4.7
(and maybe beyond) core. It was removed from Drupal 7 core, but continues to
live on as a contributed theme.

It is a classic table-based, multi-column, recolorable theme that goes against
all modern semantic, responsive, etc. design, but works very well as a
utilitarian theme. It is good for when what you want is to display information
in a neat and clean way, and you don't care too much about whether the display
is pretty, frilly, or fancy.

This version of the theme will allow you to change the colors of some areas,
if the Color module is enabled.
