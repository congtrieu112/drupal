<div class="ipad-box9">
    
            <h4>PLACE YOUR BOOKING HERE!!!</h4>
            <div class="mCont">
                <form>
                    <fieldset>
                        <label class="q1"> Year
                            <input type="text">
                        </label>
                        <label class="q1"> Day
                            <input type="text">
                        </label>
                        <label class="q1"> Month
                            <input type="text">
                        </label>
                        <label class="q1"> Time
                            <input type="text">
                        </label>
                        <label class="q2"> Name
                            <input type="text">
                        </label>
                        <label class="q1"> Guests
                            <input type="tprintext">
                        </label>
                        <label> E-mail
                            <input type="text">
                        </label>
                        <label class="q3"> Telephone
                            <input type="text">
                        </label>
                        <label> Special request
                            <textarea></textarea>
                        </label>
                        <div class="submitHolder">
                            <input type="submit" value="place booking">
                        </div>
                        <div class="clearfix"></div>
                    </fieldset>
                </form>
            </div>
        </div>
        <div class="topBar">
            <div class="backg"></div>
            <a href="#" class="bookTable">Book a table</a></div>
        <div id="header">
            <div class="container">
                <div class="logoContainer"> <a href="1_home.html"><img src="<?php print blogdrupal_root_template() ?>/img/logo.png" alt=""></a> </div>
                <div class="topData">
                    <ul class="social">
                        <li><a href="#" class="fb">Facebook</a></li>
                        <li><a href="#" class="twit">Twitter</a></li>
                        <li><a href="#" class="rss">Rss</a></li>
                        <li><a href="#" class="mail">E-mail</a></li>
                    </ul>
                    <address>
                        123 Eastern 12th ST New York, NY +49 1234 56789-0
                    </address>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
        <div id="menuContainer">
            <div class="container">
                <?php
                $main_menu = menu_navigation_links('main-menu');
//                print_r($main_menu);


//               print blogdrupal_links__system_main_menu($main_menu);
//                print theme('links', array(
//                    'links' => $main_menu,
//                    'attributes' => array(
//                        'id' => 'main-menu',
//                        'class' => array('links', 'clearfix'),
//                    ),
//
//                    'heading' => array(
//                        'text' => t('Main menu'),
//                        'level' => 'h2',
//                        'class' => array('element-invisible'),
//                    ),
//                ));
                ?>

                <ul class="mainMenu" id="nav">
                    <?php blogdrupal_custom_main_menu($main_menu); ?>
<!--                    <li class="subMenu"><a href="#">Home</a>-->
<!--                        <ul>-->
<!--                            <li><a href="1_home.html">2 column</a></li>-->
<!--                            <li><a href="2_home2.html">Fullwidth</a></li>-->
<!--                        </ul>-->
<!--                    </li>-->
<!--                    <li><a href="3_about.html">About<span class="addTxt"> Were real foodies</span></a></li>-->
<!--                    <li class="subMenu"> <a href="#">Menucard<span class="addTxt"> Our real tasty food</span></a>-->
<!--                        <ul>-->
<!--                            <li><a href="4_menucard1.html">2 column</a></li>-->
<!--                            <li><a href="5_menucard2.html">Fullwidth</a></li>-->
<!--                            <li><a href="4_menucard1.html#&amp;panel1-1">Starters</a></li>-->
<!--                            <li><a href="4_menucard1.html#&amp;panel1-2">Main dish</a></li>-->
<!--                            <li><a href="4_menucard1.html#&amp;panel1-3">Dessert</a></li>-->
<!--                            <li><a href="4_menucard1.html#&amp;panel1-4">Drinks</a></li>-->
<!--                        </ul>-->
<!--                    </li>-->
<!--                    <li><a href="10_gallery.html">Gallery<span class="addTxt"> Look, were so proud</span></a></li>-->
<!--                    <li class="subMenu"><a href="#">Blog<span class="addTxt"> Always be informed</span></a>-->
<!--                        <ul>-->
<!--                            <li><a href="7_blog.html">Blog</a></li>-->
<!--                            <li><a href="8_single.html">Single</a></li>-->
<!--                        </ul>-->
<!--                    </li>-->
<!--                    <li><a href="6_contact.html">Contact<span class="addTxt"> Get & stay in contact</span></a></li>-->
                </ul>
                <div class="login"> <a href="#" class="bookTable" id="bkTable">Book a table</a>
                    <ul>
                        <li><a href="#">Login</a></li>
                        <li><a href="#">Password</a></li>
                    </ul>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
        <div id="mainContent" class="sliderBack">
            <div class="container">
                <div class="column1 pull-left">
                    <div class="slider1Back">
                        <div class="slider1"> <img src="<?php print blogdrupal_root_template() ?>/img/slider1-frame.png" alt="" class="frame1">
                            <div class="sliderContent">
                                <div class="slider-wrapper">
                                    <?php $images = render( $page['slide']);
                                     $images = blogdrupal_get_all_image_content($images);

                                    ?>
                                    <div id="slider1Nivo" class="nivoSlider">
                                        <?php foreach($images as $key=>$img): ?>
                                        <div class="slider1Frame"> <img src="<?php echo $img;  ?>" alt=""> </div>

                                       <?php endforeach; ?>


                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <h2 class="hdr1">Hot & spicy from the grill</h2>
                    <h3 class="hdr2"><span class="lft"></span>Featured Dishes<span class="rt"></span></h3>
                    <div class="slider2">
                        <ul id="anythingSlider2">
                            <li>
                                <div class="setSlider2">
                                    <div class="third">
                                        <div class="mrgThird"> <span class="tx1">Grill Menu No.1</span>
                                            <p><strong>There are many</strong> variations of passages of Lorem Ipsum available, but the majority.</p>
                                            <span class="tx2">only 7.99 $</span>
                                            <div class="shadd"> <a href="<?php print blogdrupal_root_template() ?>/img/content/dish17.jpg" data-rel="lightbox"><img src="<?php print blogdrupal_root_template() ?>/img/content/dish4.jpg" alt=""></a> </div>
                                        </div>
                                    </div>
                                    <div class="third">
                                        <div class="mrgThird"> <span class="tx1">Grill Menu No.2</span>
                                            <p><strong>There are many</strong> variations of passages of Lorem Ipsum available, but the majority.</p>
                                            <span class="tx2">only 7.99 $</span>
                                            <div class="shadd"> <a href="<?php print blogdrupal_root_template() ?>/img/content/dish17.jpg" data-rel="lightbox"><img src="<?php print blogdrupal_root_template() ?>/img/content/dish5.jpg" alt=""></a> </div>
                                        </div>
                                    </div>
                                    <div class="third">
                                        <div class="mrgThird"> <span class="tx1">Grill Menu No.3</span>
                                            <p><strong>There are many</strong> variations of passages of Lorem Ipsum available, but the majority.</p>
                                            <span class="tx2">only 7.99 $</span>
                                            <div class="shadd"> <a href="<?php print blogdrupal_root_template() ?>/img/content/dish17.jpg" data-rel="lightbox"><img src="<?php print blogdrupal_root_template() ?>/img/content/dish6.jpg" alt=""></a> </div>
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                </div>
                            </li>
                            <li>
                                <div class="setSlider2">
                                    <div class="third">
                                        <div class="mrgThird"> <span class="tx1">Grill Menu No.4</span>
                                            <p><strong>There are many</strong> variations of passages of Lorem Ipsum available, but the majority.</p>
                                            <span class="tx2">only 7.99 $</span>
                                            <div class="shadd"> <a href="<?php print blogdrupal_root_template() ?>/img/content/dish17.jpg" data-rel="lightbox"><img src="<?php print blogdrupal_root_template() ?>/img/content/dish4.jpg" alt=""></a> </div>
                                        </div>
                                    </div>
                                    <div class="third">
                                        <div class="mrgThird"> <span class="tx1">Grill Menu No.5</span>
                                            <p><strong>There are many</strong> variations of passages of Lorem Ipsum available, but the majority.</p>
                                            <span class="tx2">only 7.99 $</span>
                                            <div class="shadd"> <a href="<?php print blogdrupal_root_template() ?>/img/content/dish17.jpg" data-rel="lightbox"><img src="<?php print blogdrupal_root_template() ?>/img/content/dish5.jpg" alt=""></a> </div>
                                        </div>
                                    </div>
                                    <div class="third">
                                        <div class="mrgThird"> <span class="tx1">Grill Menu No.6</span>
                                            <p><strong>There are many</strong> variations of passages of Lorem Ipsum available, but the majority.</p>
                                            <span class="tx2">only 7.99 $</span>
                                            <div class="shadd"> <a href="<?php print blogdrupal_root_template() ?>/img/content/dish17.jpg" data-rel="lightbox"><img src="<?php print blogdrupal_root_template() ?>/img/content/dish6.jpg" alt=""></a> </div>
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                </div>
                            </li>
                        </ul>
                        <a href="4_menucard1.html" class="link1">OPEN MENIUCARD</a> </div>
                    <div class="blogContent">
                        <div class="blogTitle">
                            <h2>Latest from the Blog_01</h2>
                            <span class="category">posted in // food, customer</span>
                            <div class="clearfix"></div>
                            <div class="dates"> <span class="data1">17.04.12</span> <span class="data2">22</span> </div>
                        </div>
                        <img src="<?php print blogdrupal_root_template() ?>/img/content/post1-photo.jpg" alt="">
                        <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.</p>
                        <a href="8_single.html">read more</a> </div>
                    <hr class="divider1">
                    <h3 class="hdr2"><span class="lft"></span>Recommendations for you!<span class="rt"></span></h3>
                    <div class="threeColumnGallery">
                        <div class="third">
                            <div class="mrgThird"> <span class="tx1">Grill Menu No.1</span>
                                <p><strong>There are many</strong> variations of passages of Lorem Ipsum available, but the majority.</p>
                                <span class="tx2">only 7.99 $</span> <img src="<?php print blogdrupal_root_template() ?>/img/content/dish1.jpg" alt=""> </div>
                        </div>
                        <div class="third">
                            <div class="mrgThird"> <span class="tx1">Grill Menu No.2</span>
                                <p><strong>There are many</strong> variations of passages of Lorem Ipsum available, but the majority.</p>
                                <span class="tx2">only 7.99 $</span> <img src="<?php print blogdrupal_root_template() ?>/img/content/dish2.jpg" alt=""> </div>
                        </div>
                        <div class="third">
                            <div class="mrgThird"> <span class="tx1">Grill Menu No.3</span>
                                <p><strong>There are many</strong> variations of passages of Lorem Ipsum available, but the majority.</p>
                                <span class="tx2">only 7.99 $</span> <img src="<?php print blogdrupal_root_template() ?>/img/content/dish3.jpg" alt=""> </div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>
                <div class="column2 pull-right">
                    <div class="box9">
                        <div class="top"></div>
                        <div class="mid">
                            <h4 class="curved">Book a Table</h4>
                            <span class="subTitle">Its worth!</span>
                            <div class="mCont">
                                <form id="bkForm">
                                    <fieldset>
                                        <label class="q1"> Year
                                            <input type="text">
                                        </label>
                                        <label class="q1"> Day
                                            <input type="text">
                                        </label>
                                        <label class="q1"> Month
                                            <input type="text">
                                        </label>
                                        <label class="q1"> Time
                                            <input type="text">
                                        </label>
                                        <label class="q2"> Name
                                            <input type="text">
                                        </label>
                                        <label class="q1"> Guests
                                            <input type="text">
                                        </label>
                                        <label> E-mail
                                            <input type="text" data-type="email">
                                        </label>
                                        <label> Telephone
                                            <input type="text">
                                        </label>
                                        <label> Special request
                                            <textarea></textarea>
                                        </label>
                                        <div class="clearfix"></div>
                                    </fieldset>
                                    <div class="submitHolder">
                                        <input type="submit" value="place booking">
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="btm"></div>
                    </div>
                    <div class="box1">
                        <div class="top"></div>
                        <div class="mid">
                            <h4 class="curved">Weekly Special</h4>
                            <span class="subTitle">Dont Miss them!</span>
                            <div class="mCont">
                                <h5><span>16.05.2012</span> Grill Monday</h5>
                                <p>There are many variations of passages of Lorem Ipsum available, but</p>
                                <a href="#">Read More</a>
                                <div class="clearfix"></div>
                                <h5><span>16.05.2012</span> Grill Monday</h5>
                                <p>There are many variations of passages of Lorem Ipsum available, but</p>
                                <a href="#">Read More</a>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                        <div class="btm"></div>
                    </div>
                    <div class="box2">FROM THE GRILL</div>
                    <div class="box3"> <span class="tx1">Argentinian</span> <span class="tx2">T-Bone Steak</span>
                        <p><strong>There are many</strong> variations of passages of Lorem Ipsum available, but the majority have suff.</p>
                        <span class="tx3">Only 7.99 $</span> </div>
                    <div class="box3"> <span class="tx1">New Zealand</span> <span class="tx2">Lamb Carree</span>
                        <p><strong>There are many</strong> variations of passages of Lorem Ipsum available, but the majority have suff.</p>
                        <span class="tx3">Only 7.99 $</span> </div>
                    <h4 class="hdr3">What people say!</h4>
                    <div class="box4">
                        <div class="mCont"> This is my absolute favorite restaurant. Food is always fresh. Go on like that!! </div>
                        <div class="btm"></div>
                        <img src="<?php print blogdrupal_root_template() ?>/img/content/avatar-say1.jpg" alt=""> <span class="author">Floyd, Cramer - Kansas</span>
                        <div class="clearfix"></div>
                        <hr class="divider2">
                    </div>
                    <div class="box4">
                        <div class="mCont"> This is my absolute favorite restaurant. Food is always fresh. Go on like that!! </div>
                        <div class="btm"></div>
                        <img src="<?php print blogdrupal_root_template() ?>/img/content/avatar-say1.jpg" alt=""> <span class="author">Floyd, Cramer - Kansas</span>
                        <div class="clearfix"></div>
                    </div>
                    <br>
                    <br>
                    <br>
                </div>
                <div class="c2btm">
                    <div class="photoSidebar"> <img src="<?php print blogdrupal_root_template() ?>/img/content/deco.jpg" alt=""> </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
        <div id="footer">
            <div class="container">
                <div class="top">
                    <h3 class="hdr1">Were looking forward to your visit</h3>
                </div>
                <div class="mid">
                    <div class="col1">
                        <h4><span class="lft"></span>Hours<span class="rt"></span></h4>
                        <span class="day">Monday</span> <span class="hour">11:00 am - 09:00 pm</span> <span class="day">Tuesday</span> <span class="hour">11:00 am - 09:00 pm</span> <span class="day">Wendsday</span> <span class="hour">11:00 am - 09:00 pm</span> <span class="day">Thursday</span> <span class="hour">11:00 am - 09:00 pm</span> <span class="day">Friday</span> <span class="hour">11:00 am - 09:00 pm</span> <span class="day">Saturday</span> <span class="hour">11:00 am - 09:00 pm</span> <span class="day">Sunday</span> <span class="hour">11:00 am - 09:00 pm</span> </div>
                    <div class="col2">
                        <h4><span class="lft"></span>Contact & Location<span class="rt"></span></h4>
                        <div class="brdr">
                            <div class="ftMap">
                                <iframe width="151" height="117" src="http://maps.google.pl/maps?f=q&amp;source=s_q&amp;hl=pl&amp;geocode=&amp;q=123+Eastern+12th+ST+New+York,+NY&amp;aq=&amp;sll=51.923943,27.608643&amp;sspn=6.879039,16.907959&amp;ie=UTF8&amp;hq=123+Eastern&amp;hnear=W+12th+St,+New+York,+Stany+Zjednoczone&amp;ll=40.741588,-73.990536&amp;spn=0.016663,0.024356&amp;t=m&amp;output=embed&amp;iwloc=near"></iframe>
                                <br/>
                                <small><a href="http://maps.google.pl/maps?f=q&amp;source=embed&amp;hl=pl&amp;geocode=&amp;q=123+Eastern+12th+ST+New+York,+NY&amp;aq=&amp;sll=51.923943,27.608643&amp;sspn=6.879039,16.907959&amp;ie=UTF8&amp;hq=123+Eastern&amp;hnear=W+12th+St,+New+York,+Stany+Zjednoczone&amp;ll=40.741588,-73.990536&amp;spn=0.016663,0.024356&amp;t=m" style="color:#0000FF;text-align:left">Get Directions</a></small></div>
                            <p> 123 Eastern 12th ST New York, NY, North America<br>
                                <br>
                                +49 1234 56789-0 +49 1234 56789-12<br>
                                <br>
                                <a href="mailto:info@delimondo.com">info@delimondo.com</a> <a href="#">www.delimondo.com</a> </p>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                    <div class="col3">
                        <div class="lftMrg">
                            <h4><span class="lft"></span>Latest Blog Post<span class="rt"></span></h4>
                            <span class="data1">22 June, 2011 <img src="<?php print blogdrupal_root_template() ?>/img/data1-dot.png" alt=""> no comments</span> <a href="#">Pellentesque habitant morbi tristique senectus et netus et male. </a> <span class="data1">7 May, 2011 <img src="<?php print blogdrupal_root_template() ?>/img/data1-dot.png" alt=""> 11 comments</span> <a href="#">Pellentesque habitant morbi tristique senectus et netus et male. </a> </div>
                    </div>
                    <div class="clearfix"></div>
                </div>
                <div class="btm"></div>
                <div class="footNotes">
                    <ul class="social">
                        <li><a href="#" class="fb">Facebook</a></li>
                        <li><a href="#" class="twit">Twitter</a></li>
                        <li><a href="#" class="rss">Rss</a></li>
                        <li><a href="#" class="mail">E-mail</a></li>
                    </ul>
                    <p>All Content © Copyright 2012 - This work is licensed under a Creative Commons License.</p>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
